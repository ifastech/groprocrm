// Dashboard Data Management
let dashboardData = {
    leads: [],
    properties: [],
    siteVisits: [],
    followups: []
};

// Initialize Dashboard
document.addEventListener('DOMContentLoaded', function() {
    loadDashboardData();
    setupEventListeners();
    refreshDashboard();
});

// Load Data
async function loadDashboardData() {
    try {
        // In a real application, these would be API calls
        // For now, we'll use mock data
        dashboardData = {
            leads: await fetchLeads(),
            properties: await fetchProperties(),
            siteVisits: await fetchSiteVisits(),
            followups: await fetchFollowups()
        };
        updateDashboard();
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Update Dashboard UI
function updateDashboard() {
    updateStatCards();
    updateSiteVisitsList();
    updateFollowupsList();
}

// Update Stat Cards
function updateStatCards() {
    document.getElementById('totalLeadsCount').textContent = dashboardData.leads.length;
    document.getElementById('activePropertiesCount').textContent = dashboardData.properties.filter(p => p.status === 'active').length;
    document.getElementById('todaySiteVisitsCount').textContent = getTodaySiteVisits().length;
    document.getElementById('pendingFollowupsCount').textContent = getPendingFollowups().length;
}

// Get Today's Site Visits
function getTodaySiteVisits() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return dashboardData.siteVisits.filter(visit => {
        const visitDate = new Date(visit.date);
        visitDate.setHours(0, 0, 0, 0);
        return visitDate.getTime() === today.getTime();
    });
}

// Get Pending Follow-ups
function getPendingFollowups() {
    const now = new Date();
    return dashboardData.followups.filter(followup => 
        new Date(followup.dueDate) >= now && !followup.completed
    );
}

// Update Site Visits List
function updateSiteVisitsList() {
    const listElement = document.getElementById('todaySiteVisitsList');
    const todayVisits = getTodaySiteVisits();
    
    listElement.innerHTML = todayVisits.length ? '' : '<div class="text-center text-muted py-3">No site visits scheduled for today</div>';
    
    todayVisits.forEach(visit => {
        const time = new Date(visit.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        listElement.innerHTML += `
            <div class="list-group-item visit-item">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1">${visit.propertyName}</h6>
                        <small class="text-muted">
                            <i class="fas fa-user"></i> ${visit.clientName} | 
                            <i class="fas fa-user-tie"></i> ${visit.agentName}
                        </small>
                    </div>
                    <span class="time-badge bg-info text-white">
                        <i class="fas fa-clock"></i> ${time}
                    </span>
                </div>
            </div>
        `;
    });
}

// Update Follow-ups List
function updateFollowupsList() {
    const listElement = document.getElementById('followupsList');
    const pendingFollowups = getPendingFollowups();
    
    listElement.innerHTML = pendingFollowups.length ? '' : '<div class="text-center text-muted py-3">No pending follow-ups</div>';
    
    pendingFollowups.forEach(followup => {
        const dueDate = new Date(followup.dueDate).toLocaleDateString();
        listElement.innerHTML += `
            <div class="list-group-item followup-item">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1">${followup.title}</h6>
                        <small class="text-muted">
                            <i class="fas fa-user"></i> ${followup.clientName} | 
                            <i class="fas fa-tag"></i> ${followup.type}
                        </small>
                    </div>
                    <span class="time-badge bg-warning text-white">
                        <i class="fas fa-calendar"></i> ${dueDate}
                    </span>
                </div>
            </div>
        `;
    });
}

// Setup Event Listeners
function setupEventListeners() {
    // Refresh Dashboard
    document.getElementById('refreshDashboard').addEventListener('click', () => {
        loadDashboardData();
    });

    // Add Site Visit Button
    document.getElementById('addSiteVisitBtn').addEventListener('click', () => {
        // Implement site visit scheduling functionality
        console.log('Add site visit clicked');
    });

    // Add Follow-up Button
    document.getElementById('addFollowupBtn').addEventListener('click', () => {
        // Implement follow-up creation functionality
        console.log('Add follow-up clicked');
    });
}

// Mock Data Functions (Replace with actual API calls)
async function fetchLeads() {
    return [
        { id: 1, name: 'John Doe', status: 'New' },
        { id: 2, name: 'Jane Smith', status: 'Contacted' }
    ];
}

async function fetchProperties() {
    return [
        { id: 1, name: 'Luxury Villa', status: 'active' },
        { id: 2, name: 'City Apartment', status: 'active' }
    ];
}

async function fetchSiteVisits() {
    const today = new Date();
    return [
        {
            id: 1,
            propertyName: 'Luxury Villa',
            clientName: 'John Doe',
            agentName: 'Mike Johnson',
            date: today.setHours(14, 30)
        },
        {
            id: 2,
            propertyName: 'City Apartment',
            clientName: 'Jane Smith',
            agentName: 'Sarah Wilson',
            date: today.setHours(16, 0)
        }
    ];
}

async function fetchFollowups() {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return [
        {
            id: 1,
            title: 'Property Discussion',
            clientName: 'John Doe',
            type: 'Call',
            dueDate: today,
            completed: false
        },
        {
            id: 2,
            title: 'Document Collection',
            clientName: 'Jane Smith',
            type: 'Meeting',
            dueDate: tomorrow,
            completed: false
        }
    ];
}
