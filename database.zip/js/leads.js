// Leads Management

document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    if (!window.auth || !window.auth.isAuthenticated) {
        window.location.href = 'login.html';
        return;
    }

    // Initialize navigation with active page
    Navigation.init('leads');

    // Initialize Lead Manager
    const leadsManager = new LeadsManager();
});

class LeadsManager {
    constructor() {
        this.leads = [];
        this.clients = [];
        this.currentUser = auth.getCurrentUser();
        this.loadData();
        this.initializeEventListeners();
    }

    loadData() {
        this.leads = DataStorage.getData('leads') || [];
        this.clients = DataStorage.getData('clients') || [];
        this.filterDataForCurrentUser();
        this.updateViews();
    }

    filterDataForCurrentUser() {
        if (!this.currentUser) return;

        // If not admin, only show user's own leads and clients
        if (!auth.hasPermission('leads', 'viewAll')) {
            this.leads = this.leads.filter(lead => lead.assignedTo === this.currentUser.id);
            this.clients = this.clients.filter(client => client.assignedTo === this.currentUser.id);
        }
    }

    initializeEventListeners() {
        // Add Lead Form
        document.getElementById('addLeadForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAddLead(e.target);
        });

        // Add Client Form
        document.getElementById('addClientForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAddClient(e.target);
        });

        // Search and Filter
        const filterInputs = ['leadStatusFilter', 'leadSourceFilter', 'leadSearch'];
        filterInputs.forEach(id => {
            document.getElementById(id)?.addEventListener('input', 
                this.debounce(() => this.updateViews(), 300)
            );
        });
    }

    handleAddLead(form) {
        const formData = new FormData(form);
        const newLead = {
            id: 'lead_' + Date.now(),
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            source: formData.get('source'),
            status: 'New',
            propertyInterest: formData.get('propertyInterest'),
            budget: parseFloat(formData.get('budget')),
            notes: formData.get('notes'),
            assignedTo: this.currentUser.id,
            createdAt: new Date().toISOString(),
            lastUpdated: new Date().toISOString(),
            followUps: []
        };

        this.leads.push(newLead);
        this.saveLeads();
        this.updateViews();
        
        bootstrap.Modal.getInstance(document.getElementById('addLeadModal')).hide();
        form.reset();
        NotificationSystem.show('Lead added successfully', 'success');
    }

    handleAddClient(form) {
        const formData = new FormData(form);
        const newClient = {
            id: 'client_' + Date.now(),
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            address: formData.get('address'),
            propertyPurchased: formData.get('propertyPurchased'),
            purchaseDate: formData.get('purchaseDate'),
            assignedTo: this.currentUser.id,
            createdAt: new Date().toISOString(),
            lastUpdated: new Date().toISOString(),
            notes: formData.get('notes')
        };

        this.clients.push(newClient);
        this.saveClients();
        this.updateViews();
        
        bootstrap.Modal.getInstance(document.getElementById('addClientModal')).hide();
        form.reset();
        NotificationSystem.show('Client added successfully', 'success');
    }

    updateViews() {
        this.updateLeadsView();
        this.updateClientsView();
        this.updateDashboardStats();
    }

    updateLeadsView() {
        const filteredLeads = this.getFilteredLeads();
        const leadsContainer = document.getElementById('leadsTableBody');
        if (!leadsContainer) return;

        leadsContainer.innerHTML = filteredLeads.map(lead => `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="ms-2">
                            <div class="fw-bold">${lead.name}</div>
                            <div class="small text-muted">${lead.email}</div>
                        </div>
                    </div>
                </td>
                <td>${lead.phone}</td>
                <td><span class="badge bg-${this.getStatusColor(lead.status)}">${lead.status}</span></td>
                <td>${lead.source}</td>
                <td>₹${lead.budget.toLocaleString()}</td>
                <td>${new Date(lead.createdAt).toLocaleDateString()}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary" onclick="leadsManager.viewLead('${lead.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-primary" onclick="leadsManager.editLead('${lead.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-success" onclick="leadsManager.addFollowUp('${lead.id}')">
                            <i class="fas fa-phone"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    updateClientsView() {
        const clientsContainer = document.getElementById('clientsTableBody');
        if (!clientsContainer) return;

        clientsContainer.innerHTML = this.clients.map(client => `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="ms-2">
                            <div class="fw-bold">${client.name}</div>
                            <div class="small text-muted">${client.email}</div>
                        </div>
                    </div>
                </td>
                <td>${client.phone}</td>
                <td>${client.propertyPurchased || 'N/A'}</td>
                <td>${client.purchaseDate ? new Date(client.purchaseDate).toLocaleDateString() : 'N/A'}</td>
                <td>${new Date(client.createdAt).toLocaleDateString()}</td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-primary" onclick="leadsManager.viewClient('${client.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-primary" onclick="leadsManager.editClient('${client.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    updateDashboardStats() {
        // Update dashboard statistics if on dashboard page
        const statsContainer = document.getElementById('leadStats');
        if (!statsContainer) return;

        const totalLeads = this.leads.length;
        const newLeads = this.leads.filter(lead => lead.status === 'New').length;
        const activeLeads = this.leads.filter(lead => lead.status === 'Active').length;
        const convertedLeads = this.leads.filter(lead => lead.status === 'Converted').length;

        statsContainer.innerHTML = `
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Leads</h5>
                        <h2>${totalLeads}</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">New Leads</h5>
                        <h2>${newLeads}</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-dark">
                    <div class="card-body">
                        <h5 class="card-title">Active Leads</h5>
                        <h2>${activeLeads}</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Converted</h5>
                        <h2>${convertedLeads}</h2>
                    </div>
                </div>
            </div>
        `;
    }

    getFilteredLeads() {
        const statusFilter = document.getElementById('leadStatusFilter')?.value.toLowerCase();
        const sourceFilter = document.getElementById('leadSourceFilter')?.value.toLowerCase();
        const searchTerm = document.getElementById('leadSearch')?.value.toLowerCase();

        return this.leads.filter(lead => {
            const matchesStatus = !statusFilter || lead.status.toLowerCase() === statusFilter;
            const matchesSource = !sourceFilter || lead.source.toLowerCase() === sourceFilter;
            const matchesSearch = !searchTerm || 
                lead.name.toLowerCase().includes(searchTerm) ||
                lead.email.toLowerCase().includes(searchTerm) ||
                lead.phone.includes(searchTerm);

            return matchesStatus && matchesSource && matchesSearch;
        });
    }

    viewLead(id) {
        const lead = this.leads.find(l => l.id === id);
        if (!lead) {
            NotificationSystem.show('Lead not found', 'error');
            return;
        }

        // Populate lead details modal
        document.getElementById('viewLeadName').textContent = lead.name;
        document.getElementById('viewLeadEmail').textContent = lead.email;
        document.getElementById('viewLeadPhone').textContent = lead.phone;
        document.getElementById('viewLeadStatus').textContent = lead.status;
        document.getElementById('viewLeadSource').textContent = lead.source;
        document.getElementById('viewLeadBudget').textContent = `₹${lead.budget.toLocaleString()}`;
        document.getElementById('viewLeadNotes').textContent = lead.notes;

        // Show follow-ups if any
        const followUpsContainer = document.getElementById('viewLeadFollowUps');
        followUpsContainer.innerHTML = lead.followUps?.map(followUp => `
            <div class="mb-2 p-2 border rounded">
                <div class="d-flex justify-content-between">
                    <strong>${new Date(followUp.date).toLocaleDateString()}</strong>
                    <span class="badge bg-${this.getStatusColor(followUp.status)}">${followUp.status}</span>
                </div>
                <p class="mb-0">${followUp.notes}</p>
            </div>
        `).join('') || '<p class="text-muted">No follow-ups yet</p>';

        const modal = new bootstrap.Modal(document.getElementById('viewLeadModal'));
        modal.show();
    }

    addFollowUp(leadId) {
        const lead = this.leads.find(l => l.id === leadId);
        if (!lead) {
            NotificationSystem.show('Lead not found', 'error');
            return;
        }

        document.getElementById('followUpLeadId').value = leadId;
        document.getElementById('followUpLeadName').textContent = lead.name;

        const modal = new bootstrap.Modal(document.getElementById('addFollowUpModal'));
        modal.show();
    }

    handleAddFollowUp(form) {
        const formData = new FormData(form);
        const leadId = formData.get('leadId');
        const lead = this.leads.find(l => l.id === leadId);
        
        if (!lead) {
            NotificationSystem.show('Lead not found', 'error');
            return;
        }

        const followUp = {
            id: 'followup_' + Date.now(),
            date: new Date().toISOString(),
            status: formData.get('status'),
            notes: formData.get('notes'),
            nextFollowUp: formData.get('nextFollowUp'),
            createdBy: this.currentUser.id
        };

        lead.followUps = lead.followUps || [];
        lead.followUps.push(followUp);
        lead.status = formData.get('status');
        lead.lastUpdated = new Date().toISOString();

        this.saveLeads();
        this.updateViews();
        
        bootstrap.Modal.getInstance(document.getElementById('addFollowUpModal')).hide();
        form.reset();
        NotificationSystem.show('Follow-up added successfully', 'success');
    }

    getStatusColor(status) {
        const colors = {
            'New': 'info',
            'Active': 'primary',
            'Hot': 'danger',
            'Warm': 'warning',
            'Cold': 'secondary',
            'Converted': 'success',
            'Lost': 'dark'
        };
        return colors[status] || 'secondary';
    }

    saveLeads() {
        DataStorage.saveData('leads', this.leads);
    }

    saveClients() {
        DataStorage.saveData('clients', this.clients);
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notification.role = 'alert';
        notification.style.zIndex = '1050';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}

// Export LeadManager
window.leadsManager = new LeadsManager();
