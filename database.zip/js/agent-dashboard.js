// Agent Dashboard Controller

class AgentDashboard {
    constructor() {
        this.leads = DataStorage.getData('leads') || [];
        this.properties = DataStorage.getData('properties') || [];
        this.siteVisits = DataStorage.getData('siteVisits') || [];
        this.followups = DataStorage.getData('followups') || [];
        this.clients = DataStorage.getData('clients') || [];
        
        this.setupEventListeners();
        this.updateDashboard();
    }

    setupEventListeners() {
        // Dashboard timeframe change
        const timeframeSelect = document.getElementById('dashboardTimeframe');
        if (timeframeSelect) {
            timeframeSelect.addEventListener('change', () => {
                this.updateDashboard();
            });
        }

        // Site Visit Form
        const siteVisitForm = document.getElementById('siteVisitForm');
        if (siteVisitForm) {
            siteVisitForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.scheduleSiteVisit();
            });
        }

        // Follow-up Form
        const followupForm = document.getElementById('followupForm');
        if (followupForm) {
            followupForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addFollowup();
            });
        }

        // Complete Follow-up Form
        const completeFollowupForm = document.getElementById('completeFollowupForm');
        if (completeFollowupForm) {
            completeFollowupForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.finishFollowup();
            });
        }

        // Follow-up Outcome Change
        const followupOutcome = document.getElementById('followupOutcome');
        if (followupOutcome) {
            followupOutcome.addEventListener('change', (e) => {
                const rescheduleSection = document.getElementById('rescheduleSection');
                rescheduleSection.style.display = e.target.value === 'rescheduled' ? 'block' : 'none';
            });
        }

        // Complete Site Visit Button
        const completeSiteVisitBtn = document.getElementById('completeSiteVisitBtn');
        if (completeSiteVisitBtn) {
            completeSiteVisitBtn.addEventListener('click', () => {
                this.completeSiteVisit();
            });
        }

        // Listen for data changes
        window.addEventListener('leadAdded', () => this.updateDashboard());
        window.addEventListener('leadUpdated', () => this.updateDashboard());
        window.addEventListener('propertyUpdated', () => this.updateDashboard());
        window.addEventListener('siteVisitAdded', () => this.updateDashboard());
        window.addEventListener('siteVisitUpdated', () => this.updateDashboard());
        window.addEventListener('followupAdded', () => this.updateDashboard());
        window.addEventListener('followupUpdated', () => this.updateDashboard());

        // Initialize modals when showing
        const scheduleSiteVisitModal = document.getElementById('scheduleSiteVisitModal');
        if (scheduleSiteVisitModal) {
            scheduleSiteVisitModal.addEventListener('show.bs.modal', () => {
                this.populateClientSelect('siteVisitClient');
                this.populatePropertySelect('siteVisitProperty');
            });
        }

        const addFollowupModal = document.getElementById('addFollowupModal');
        if (addFollowupModal) {
            addFollowupModal.addEventListener('show.bs.modal', () => {
                this.populateClientSelect('followupClient');
            });
        }
    }

    updateDashboard() {
        const timeframe = document.getElementById('dashboardTimeframe').value;
        const { startDate, endDate } = this.getDateRange(timeframe);
        
        this.updateStats(startDate, endDate);
        this.updateSiteVisitsList();
        this.updateFollowupsList();
    }

    getDateRange(timeframe) {
        const now = new Date();
        let startDate = new Date();
        const endDate = now;

        switch (timeframe) {
            case 'today':
                startDate.setHours(0, 0, 0, 0);
                break;
            case 'week':
                startDate.setDate(now.getDate() - 7);
                break;
            case 'month':
                startDate.setMonth(now.getMonth() - 1);
                break;
        }

        return { startDate, endDate };
    }

    updateStats(startDate, endDate) {
        const activeLeads = this.leads.filter(lead => 
            lead.assignedTo === auth.currentUser.id &&
            lead.status !== 'Closed' && 
            lead.status !== 'Lost'
        ).length;

        const todaySiteVisits = this.getTodaySiteVisits().length;
        const pendingFollowups = this.getPendingFollowups().length;
        const propertiesShown = this.siteVisits.filter(visit =>
            visit.agentId === auth.currentUser.id &&
            visit.status === 'completed'
        ).length;

        // Update UI
        document.getElementById('myActiveLeadsCount').textContent = activeLeads;
        document.getElementById('todaySiteVisitsCount').textContent = todaySiteVisits;
        document.getElementById('pendingFollowupsCount').textContent = pendingFollowups;
        document.getElementById('propertiesShownCount').textContent = propertiesShown;
    }

    getTodaySiteVisits() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return this.siteVisits.filter(visit => {
            const visitDate = new Date(visit.date);
            visitDate.setHours(0, 0, 0, 0);
            return visitDate.getTime() === today.getTime() &&
                   visit.agentId === auth.currentUser.id &&
                   visit.status !== 'cancelled';
        });
    }

    getPendingFollowups() {
        const now = new Date();
        return this.followups.filter(followup => 
            followup.agentId === auth.currentUser.id &&
            new Date(followup.dueDate) >= now &&
            !followup.completed
        );
    }

    updateSiteVisitsList() {
        const listElement = document.getElementById('siteVisitsList');
        const todayVisits = this.getTodaySiteVisits();
        
        listElement.innerHTML = todayVisits.length ? '' : 
            '<div class="text-center text-muted py-3">No site visits scheduled for today</div>';
        
        todayVisits.forEach(visit => {
            const client = this.clients.find(c => c.id === visit.clientId);
            const property = this.properties.find(p => p.id === visit.propertyId);
            const time = new Date(visit.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            
            listElement.innerHTML += `
                <div class="list-group-item visit-item" data-visit-id="${visit.id}">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">${property ? property.title : 'Unknown Property'}</h6>
                            <small class="text-muted">
                                <i class="fas fa-user"></i> ${client ? client.name : 'Unknown Client'}
                            </small>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="time-badge bg-info text-white">
                                <i class="fas fa-clock"></i> ${time}
                            </span>
                            <button class="btn btn-sm btn-outline-primary" onclick="dashboard.viewSiteVisit('${visit.id}')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
    }

    updateFollowupsList() {
        const listElement = document.getElementById('followupsList');
        const pendingFollowups = this.getPendingFollowups();
        
        listElement.innerHTML = pendingFollowups.length ? '' : 
            '<div class="text-center text-muted py-3">No pending follow-ups</div>';
        
        pendingFollowups.forEach(followup => {
            const client = this.clients.find(c => c.id === followup.clientId);
            const dueDate = new Date(followup.dueDate).toLocaleDateString();
            const priorityColors = {
                high: 'danger',
                medium: 'warning',
                low: 'info'
            };
            
            listElement.innerHTML += `
                <div class="list-group-item followup-item" data-followup-id="${followup.id}">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">${followup.title}</h6>
                            <small class="text-muted">
                                <i class="fas fa-user"></i> ${client ? client.name : 'Unknown Client'} | 
                                <i class="fas fa-tag"></i> ${followup.type}
                            </small>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-${priorityColors[followup.priority]}">${followup.priority}</span>
                            <span class="time-badge bg-warning text-white">
                                <i class="fas fa-calendar"></i> ${dueDate}
                            </span>
                            <button class="btn btn-sm btn-success" onclick="dashboard.completeFollowup('${followup.id}')">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
    }

    scheduleSiteVisit() {
        const clientId = document.getElementById('siteVisitClient').value;
        const propertyId = document.getElementById('siteVisitProperty').value;
        const dateTime = document.getElementById('siteVisitDateTime').value;
        const notes = document.getElementById('siteVisitNotes').value;

        const siteVisit = {
            id: 'sv_' + Date.now(),
            clientId,
            propertyId,
            agentId: auth.currentUser.id,
            date: new Date(dateTime).toISOString(),
            notes,
            status: 'scheduled',
            createdAt: new Date().toISOString()
        };

        this.siteVisits.push(siteVisit);
        DataStorage.saveData('siteVisits', this.siteVisits);
        
        // Update lead status if exists
        const lead = this.leads.find(l => l.clientId === clientId);
        if (lead && lead.status === 'Contacted') {
            lead.status = 'Site Visit';
            DataStorage.saveData('leads', this.leads);
        }

        // Close modal and update dashboard
        bootstrap.Modal.getInstance(document.getElementById('scheduleSiteVisitModal')).hide();
        this.updateDashboard();
        NotificationSystem.show('Site visit scheduled successfully', 'success');
    }

    addFollowup() {
        const clientId = document.getElementById('followupClient').value;
        const type = document.getElementById('followupType').value;
        const dateTime = document.getElementById('followupDateTime').value;
        const title = document.getElementById('followupTitle').value;
        const notes = document.getElementById('followupNotes').value;
        const priority = document.getElementById('followupPriority').value;

        const followup = {
            id: 'fu_' + Date.now(),
            clientId,
            agentId: auth.currentUser.id,
            type,
            dueDate: new Date(dateTime).toISOString(),
            title,
            notes,
            priority,
            completed: false,
            createdAt: new Date().toISOString()
        };

        this.followups.push(followup);
        DataStorage.saveData('followups', this.followups);

        // Close modal and update dashboard
        bootstrap.Modal.getInstance(document.getElementById('addFollowupModal')).hide();
        this.updateDashboard();
        NotificationSystem.show('Follow-up added successfully', 'success');
    }

    viewSiteVisit(visitId) {
        const visit = this.siteVisits.find(v => v.id === visitId);
        if (!visit) return;

        const client = this.clients.find(c => c.id === visit.clientId);
        const property = this.properties.find(p => p.id === visit.propertyId);
        const detailsElement = document.getElementById('siteVisitDetails');
        
        detailsElement.innerHTML = `
            <div class="mb-3">
                <h6>Property</h6>
                <p>${property ? property.title : 'Unknown Property'}</p>
            </div>
            <div class="mb-3">
                <h6>Client</h6>
                <p>${client ? client.name : 'Unknown Client'}</p>
            </div>
            <div class="mb-3">
                <h6>Date & Time</h6>
                <p>${new Date(visit.date).toLocaleString()}</p>
            </div>
            <div class="mb-3">
                <h6>Status</h6>
                <p>${visit.status.charAt(0).toUpperCase() + visit.status.slice(1)}</p>
            </div>
            ${visit.notes ? `
                <div class="mb-3">
                    <h6>Notes</h6>
                    <p>${visit.notes}</p>
                </div>
            ` : ''}
        `;

        const completeSiteVisitBtn = document.getElementById('completeSiteVisitBtn');
        completeSiteVisitBtn.style.display = visit.status === 'scheduled' ? 'block' : 'none';
        completeSiteVisitBtn.dataset.visitId = visitId;

        const modal = new bootstrap.Modal(document.getElementById('viewSiteVisitModal'));
        modal.show();
    }

    completeSiteVisit() {
        const visitId = document.getElementById('completeSiteVisitBtn').dataset.visitId;
        const visit = this.siteVisits.find(v => v.id === visitId);
        if (!visit) return;

        visit.status = 'completed';
        visit.completedAt = new Date().toISOString();
        DataStorage.saveData('siteVisits', this.siteVisits);

        // Close modal and update dashboard
        bootstrap.Modal.getInstance(document.getElementById('viewSiteVisitModal')).hide();
        this.updateDashboard();
        NotificationSystem.show('Site visit marked as completed', 'success');
    }

    completeFollowup(followupId) {
        const followup = this.followups.find(f => f.id === followupId);
        if (!followup) return;

        // Show complete followup modal
        const modal = new bootstrap.Modal(document.getElementById('completeFollowupModal'));
        document.getElementById('completeFollowupForm').dataset.followupId = followupId;
        modal.show();
    }

    finishFollowup() {
        const followupId = document.getElementById('completeFollowupForm').dataset.followupId;
        const outcome = document.getElementById('followupOutcome').value;
        const notes = document.getElementById('followupCompletionNotes').value;
        const rescheduleDate = document.getElementById('rescheduleDateTime').value;

        const followup = this.followups.find(f => f.id === followupId);
        if (!followup) return;

        if (outcome === 'rescheduled' && rescheduleDate) {
            // Create new follow-up
            const newFollowup = {
                ...followup,
                id: 'fu_' + Date.now(),
                dueDate: new Date(rescheduleDate).toISOString(),
                notes: `Rescheduled from ${new Date(followup.dueDate).toLocaleDateString()}\n${notes}`,
                createdAt: new Date().toISOString()
            };
            this.followups.push(newFollowup);
        }

        followup.completed = true;
        followup.completedAt = new Date().toISOString();
        followup.outcome = outcome;
        followup.completionNotes = notes;

        DataStorage.saveData('followups', this.followups);

        // Close modal and update dashboard
        bootstrap.Modal.getInstance(document.getElementById('completeFollowupModal')).hide();
        this.updateDashboard();
        NotificationSystem.show('Follow-up completed successfully', 'success');
    }

    populateClientSelect(selectId) {
        const select = document.getElementById(selectId);
        if (!select) return;

        const myClients = this.clients.filter(client => 
            this.leads.some(lead => 
                lead.clientId === client.id && 
                lead.assignedTo === auth.currentUser.id
            )
        );

        select.innerHTML = '<option value="">Select Client</option>';
        myClients.forEach(client => {
            select.innerHTML += `<option value="${client.id}">${client.name}</option>`;
        });
    }

    populatePropertySelect(selectId) {
        const select = document.getElementById(selectId);
        if (!select) return;

        const availableProperties = this.properties.filter(property => 
            property.status === 'active'
        );

        select.innerHTML = '<option value="">Select Property</option>';
        availableProperties.forEach(property => {
            select.innerHTML += `<option value="${property.id}">${property.title}</option>`;
        });
    }
}

// Initialize Agent Dashboard
const dashboard = new AgentDashboard();

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        const container = document.createElement('div');
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        container.appendChild(toast);
        document.body.appendChild(container);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        toast.addEventListener('hidden.bs.toast', () => {
            container.remove();
        });
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
        window.dispatchEvent(new Event(key + 'Updated'));
    }
    
    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}
