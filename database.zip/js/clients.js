// Client Management System

class ClientManager {
    constructor() {
        this.clients = DataStorage.getData('clients') || [];
        this.setupEventListeners();
        this.updateClientsView();
        this.setupLeadListener();
    }

    setupEventListeners() {
        // Add Client Form Handler
        const addClientForm = document.getElementById('addClientForm');
        if (addClientForm) {
            addClientForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (!auth.hasPermission('clients', 'create')) {
                    NotificationSystem.show('You do not have permission to add clients', 'error');
                    return;
                }
                this.addClient(this.getFormData(addClientForm));
            });
        }

        // Client Type Filter
        const clientTypeFilter = document.getElementById('clientTypeFilter');
        if (clientTypeFilter) {
            clientTypeFilter.addEventListener('change', () => this.applyFilters());
        }

        // Status Filter
        const statusFilter = document.getElementById('statusFilter');
        if (statusFilter) {
            statusFilter.addEventListener('change', () => this.applyFilters());
        }

        // Location Filter
        const locationFilter = document.getElementById('locationFilter');
        if (locationFilter) {
            locationFilter.addEventListener('input', () => this.applyFilters());
        }

        // Search Clients
        const clientSearch = document.getElementById('clientSearch');
        if (clientSearch) {
            clientSearch.addEventListener('input', () => this.applyFilters());
        }
    }

    setupLeadListener() {
        // Listen for new leads and convert them to clients
        window.addEventListener('leadAdded', (event) => {
            const lead = event.detail;
            this.convertLeadToClient(lead);
        });
    }

    convertLeadToClient(lead) {
        // Check if client already exists with this contact number or email
        const existingClient = this.clients.find(client => 
            client.contact === lead.contact || 
            (lead.email && client.email === lead.email)
        );

        if (existingClient) {
            // Update existing client with new lead information
            existingClient.lastInteraction = new Date().toISOString();
            existingClient.leads = existingClient.leads || [];
            existingClient.leads.push({
                leadId: lead.id,
                date: new Date().toISOString(),
                status: lead.status
            });
            this.updateClient(existingClient.id, existingClient);
        } else {
            // Create new client from lead
            const clientData = {
                id: Date.now(),
                fullName: lead.name,
                contact: lead.contact,
                email: lead.email,
                location: lead.location,
                clientType: 'Buyer', // Default to buyer, can be updated later
                status: 'Active',
                source: lead.source,
                budget: lead.budget,
                createdAt: new Date().toISOString(),
                lastInteraction: new Date().toISOString(),
                leads: [{
                    leadId: lead.id,
                    date: new Date().toISOString(),
                    status: lead.status
                }],
                notes: lead.notes,
                assignedTo: lead.assignedTo
            };
            this.addClient(clientData, false); // false means don't show notification
        }
    }

    getFormData(form) {
        const formData = new FormData(form);
        const preferences = Array.from(formData.getAll('preferences'));

        return {
            id: Date.now(),
            fullName: formData.get('fullName'),
            clientType: formData.get('clientType'),
            contact: formData.get('contact'),
            email: formData.get('email'),
            location: formData.get('location'),
            status: formData.get('status'),
            preferences: preferences,
            notes: formData.get('notes'),
            createdAt: new Date().toISOString(),
            lastInteraction: new Date().toISOString(),
            createdBy: auth.currentUser.id
        };
    }

    addClient(clientData, showNotification = true) {
        this.clients.push(clientData);
        this.saveClients();
        this.updateClientsView();
        
        if (showNotification) {
            NotificationSystem.show('Client added successfully', 'success');
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('addClientModal'));
            if (modal) modal.hide();
        }
    }

    updateClient(id, updatedData) {
        if (!auth.hasPermission('clients', 'update')) {
            NotificationSystem.show('You do not have permission to update clients', 'error');
            return;
        }
        const index = this.clients.findIndex(client => client.id === id);
        if (index !== -1) {
            this.clients[index] = { 
                ...this.clients[index], 
                ...updatedData,
                lastUpdated: new Date().toISOString()
            };
            this.saveClients();
            this.updateClientsView();
            NotificationSystem.show('Client updated successfully', 'success');
        }
    }

    deleteClient(id) {
        if (!auth.hasPermission('clients', 'delete')) {
            NotificationSystem.show('You do not have permission to delete clients', 'error');
            return;
        }
        if (confirm('Are you sure you want to delete this client?')) {
            this.clients = this.clients.filter(client => client.id !== id);
            this.saveClients();
            this.updateClientsView();
            NotificationSystem.show('Client deleted successfully', 'success');
        }
    }

    applyFilters() {
        const typeFilter = document.getElementById('clientTypeFilter').value.toLowerCase();
        const statusFilter = document.getElementById('statusFilter').value.toLowerCase();
        const locationFilter = document.getElementById('locationFilter').value.toLowerCase();
        const searchTerm = document.getElementById('clientSearch').value.toLowerCase();

        const filteredClients = this.clients.filter(client => {
            const matchesType = !typeFilter || client.clientType.toLowerCase() === typeFilter;
            const matchesStatus = !statusFilter || client.status.toLowerCase() === statusFilter;
            const matchesLocation = !locationFilter || client.location.toLowerCase().includes(locationFilter);
            const matchesSearch = !searchTerm || 
                client.fullName.toLowerCase().includes(searchTerm) ||
                client.email.toLowerCase().includes(searchTerm) ||
                client.contact.includes(searchTerm);

            return matchesType && matchesStatus && matchesLocation && matchesSearch;
        });

        this.updateClientsView(filteredClients);
    }

    updateClientsView(clientsToShow = this.clients) {
        const tbody = document.getElementById('clientsTableBody');
        if (tbody) {
            tbody.innerHTML = '';
            clientsToShow.forEach(client => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${client.id}</td>
                    <td>${client.fullName}</td>
                    <td>${client.contact}</td>
                    <td>${client.email || '-'}</td>
                    <td>${client.location}</td>
                    <td><span class="badge bg-info">${client.clientType}</span></td>
                    <td><span class="badge bg-${this.getStatusColor(client.status)}">${client.status}</span></td>
                    <td>${new Date(client.lastInteraction).toLocaleDateString()}</td>
                    <td>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-info view-client" data-id="${client.id}">
                                <i class="fas fa-eye"></i>
                            </button>
                            ${auth.hasPermission('clients', 'update') ? `
                                <button class="btn btn-sm btn-primary edit-client" data-id="${client.id}">
                                    <i class="fas fa-edit"></i>
                                </button>
                            ` : ''}
                            ${auth.hasPermission('clients', 'delete') ? `
                                <button class="btn btn-sm btn-danger delete-client" data-id="${client.id}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            ` : ''}
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        this.setupClientActions();
    }

    setupClientActions() {
        // View Client
        document.querySelectorAll('.view-client').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                this.showClientDetails(id);
            });
        });

        // Edit Client
        document.querySelectorAll('.edit-client').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                this.showEditModal(id);
            });
        });

        // Delete Client
        document.querySelectorAll('.delete-client').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                this.deleteClient(id);
            });
        });
    }

    showClientDetails(id) {
        const client = this.clients.find(c => c.id === id);
        if (!client) return;

        const detailsContent = document.getElementById('clientDetailsContent');
        if (detailsContent) {
            detailsContent.innerHTML = `
                <div class="client-details">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Basic Information</h6>
                            <p><strong>Name:</strong> ${client.fullName}</p>
                            <p><strong>Contact:</strong> ${client.contact}</p>
                            <p><strong>Email:</strong> ${client.email || '-'}</p>
                            <p><strong>Location:</strong> ${client.location}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Client Details</h6>
                            <p><strong>Type:</strong> ${client.clientType}</p>
                            <p><strong>Status:</strong> ${client.status}</p>
                            <p><strong>Created:</strong> ${new Date(client.createdAt).toLocaleDateString()}</p>
                            <p><strong>Last Interaction:</strong> ${new Date(client.lastInteraction).toLocaleDateString()}</p>
                        </div>
                    </div>
                    ${client.preferences ? `
                        <div class="mb-3">
                            <h6>Preferences</h6>
                            <p>${client.preferences.join(', ') || 'No preferences set'}</p>
                        </div>
                    ` : ''}
                    ${client.notes ? `
                        <div class="mb-3">
                            <h6>Notes</h6>
                            <p>${client.notes}</p>
                        </div>
                    ` : ''}
                    ${client.leads ? `
                        <div class="mb-3">
                            <h6>Lead History</h6>
                            <ul class="list-unstyled">
                                ${client.leads.map(lead => `
                                    <li>Lead #${lead.leadId} - ${lead.status} (${new Date(lead.date).toLocaleDateString()})</li>
                                `).join('')}
                            </ul>
                        </div>
                    ` : ''}
                </div>
            `;
        }

        const modal = new bootstrap.Modal(document.getElementById('viewClientModal'));
        modal.show();
    }

    showEditModal(id) {
        const client = this.clients.find(c => c.id === id);
        if (!client) return;

        // Implement edit modal
        console.log('Show edit modal:', client);
    }

    getStatusColor(status) {
        const colors = {
            'Active': 'success',
            'Inactive': 'secondary'
        };
        return colors[status] || 'secondary';
    }

    saveClients() {
        DataStorage.saveData('clients', this.clients);
    }
}

// Initialize Client Manager
const clientManager = new ClientManager();

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notification.role = 'alert';
        notification.style.zIndex = '1050';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}
