// Reports & Analytics System

class ReportManager {
    constructor() {
        this.leads = DataStorage.getData('leads') || [];
        this.properties = DataStorage.getData('properties') || [];
        this.agents = DataStorage.getData('agents') || [];
        this.clients = DataStorage.getData('clients') || [];
        this.setupDateRangePicker();
        this.initializeCharts();
        this.setupEventListeners();
        this.updateReports();
    }

    setupDateRangePicker() {
        $('#dateRange').daterangepicker({
            startDate: moment().subtract(30, 'days'),
            endDate: moment(),
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, (start, end) => {
            this.updateReports(start.toDate(), end.toDate());
        });
    }

    setupEventListeners() {
        // Export Report Button
        document.getElementById('exportReportBtn').addEventListener('click', () => {
            this.exportReport();
        });

        // Custom Report Form
        document.getElementById('customReportForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.generateCustomReport(new FormData(e.target));
        });
    }

    updateReports(startDate = moment().subtract(30, 'days').toDate(), endDate = new Date()) {
        this.updateSummaryCards(startDate, endDate);
        this.updateCharts(startDate, endDate);
        this.updateAgentPerformance(startDate, endDate);
        this.updateLocationAnalysis(startDate, endDate);
    }

    updateSummaryCards(startDate, endDate) {
        const stats = this.calculateStats(startDate, endDate);
        const prevStats = this.calculateStats(
            moment(startDate).subtract(moment(endDate).diff(moment(startDate), 'days'), 'days').toDate(),
            startDate
        );

        // Update Total Revenue
        document.getElementById('totalRevenue').textContent = `₹${stats.revenue.toLocaleString('en-IN')}`;
        document.getElementById('revenueGrowth').textContent = 
            `${this.calculateGrowth(prevStats.revenue, stats.revenue)}% from last period`;

        // Update Conversion Rate
        document.getElementById('conversionRate').textContent = `${stats.conversionRate.toFixed(1)}%`;
        document.getElementById('conversionGrowth').textContent = 
            `${this.calculateGrowth(prevStats.conversionRate, stats.conversionRate)}% from last period`;

        // Update Total Leads
        document.getElementById('totalLeads').textContent = stats.totalLeads;
        document.getElementById('leadsGrowth').textContent = 
            `${stats.totalLeads - prevStats.totalLeads} from last period`;

        // Update Properties Sold
        document.getElementById('propertiesSold').textContent = stats.propertiesSold;
        document.getElementById('salesGrowth').textContent = 
            `${stats.propertiesSold - prevStats.propertiesSold} from last period`;
    }

    calculateStats(startDate, endDate) {
        const filteredLeads = this.leads.filter(lead => 
            new Date(lead.createdAt) >= startDate && new Date(lead.createdAt) <= endDate
        );

        const filteredProperties = this.properties.filter(property =>
            property.status === 'Sold' &&
            new Date(property.lastUpdated) >= startDate && new Date(property.lastUpdated) <= endDate
        );

        const revenue = filteredProperties.reduce((sum, property) => sum + property.price, 0);
        const convertedLeads = filteredLeads.filter(lead => lead.status === 'Closed').length;

        return {
            revenue,
            totalLeads: filteredLeads.length,
            propertiesSold: filteredProperties.length,
            conversionRate: filteredLeads.length ? (convertedLeads / filteredLeads.length) * 100 : 0
        };
    }

    calculateGrowth(previous, current) {
        if (!previous) return 100;
        return (((current - previous) / previous) * 100).toFixed(1);
    }

    initializeCharts() {
        // Revenue Trend Chart
        this.revenueTrendChart = new Chart(document.getElementById('revenueTrendChart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Revenue',
                    data: [],
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }, {
                    label: 'Sales Count',
                    data: [],
                    borderColor: 'rgb(255, 99, 132)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });

        // Lead Sources Chart
        this.leadSourcesChart = new Chart(document.getElementById('leadSourcesChart'), {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 206, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(153, 102, 255)'
                    ]
                }]
            }
        });

        // Lead Status Chart
        this.leadStatusChart = new Chart(document.getElementById('leadStatusChart'), {
            type: 'bar',
            data: {
                labels: ['New', 'In Progress', 'Closed', 'Lost'],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        'rgb(54, 162, 235)',
                        'rgb(255, 206, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(255, 99, 132)'
                    ]
                }]
            }
        });

        // Property Type Chart
        this.propertyTypeChart = new Chart(document.getElementById('propertyTypeChart'), {
            type: 'pie',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 206, 86)',
                        'rgb(75, 192, 192)'
                    ]
                }]
            }
        });

        // Location Analysis Chart
        this.locationAnalysisChart = new Chart(document.getElementById('locationAnalysisChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Leads',
                    data: [],
                    backgroundColor: 'rgba(75, 192, 192, 0.5)'
                }, {
                    label: 'Conversions',
                    data: [],
                    backgroundColor: 'rgba(255, 99, 132, 0.5)'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        stacked: true,
                    },
                    y: {
                        stacked: true
                    }
                }
            }
        });
    }

    updateCharts(startDate, endDate) {
        this.updateRevenueTrendChart(startDate, endDate);
        this.updateLeadSourcesChart(startDate, endDate);
        this.updateLeadStatusChart(startDate, endDate);
        this.updatePropertyTypeChart();
    }

    updateRevenueTrendChart(startDate, endDate) {
        const dates = [];
        const revenues = [];
        const sales = [];

        let currentDate = moment(startDate);
        while (currentDate <= moment(endDate)) {
            const dateStr = currentDate.format('YYYY-MM-DD');
            dates.push(currentDate.format('MMM D'));

            const dailyProperties = this.properties.filter(property =>
                property.status === 'Sold' &&
                moment(property.lastUpdated).format('YYYY-MM-DD') === dateStr
            );

            revenues.push(dailyProperties.reduce((sum, property) => sum + property.price, 0));
            sales.push(dailyProperties.length);

            currentDate = currentDate.add(1, 'days');
        }

        this.revenueTrendChart.data.labels = dates;
        this.revenueTrendChart.data.datasets[0].data = revenues;
        this.revenueTrendChart.data.datasets[1].data = sales;
        this.revenueTrendChart.update();
    }

    updateLeadSourcesChart(startDate, endDate) {
        const filteredLeads = this.leads.filter(lead =>
            new Date(lead.createdAt) >= startDate && new Date(lead.createdAt) <= endDate
        );

        const sourceCount = {};
        filteredLeads.forEach(lead => {
            sourceCount[lead.source] = (sourceCount[lead.source] || 0) + 1;
        });

        this.leadSourcesChart.data.labels = Object.keys(sourceCount);
        this.leadSourcesChart.data.datasets[0].data = Object.values(sourceCount);
        this.leadSourcesChart.update();
    }

    updateLeadStatusChart(startDate, endDate) {
        const filteredLeads = this.leads.filter(lead =>
            new Date(lead.createdAt) >= startDate && new Date(lead.createdAt) <= endDate
        );

        const statusCount = {
            'New': 0,
            'In Progress': 0,
            'Closed': 0,
            'Lost': 0
        };

        filteredLeads.forEach(lead => {
            statusCount[lead.status] = (statusCount[lead.status] || 0) + 1;
        });

        this.leadStatusChart.data.datasets[0].data = Object.values(statusCount);
        this.leadStatusChart.update();
    }

    updatePropertyTypeChart() {
        const typeCount = {};
        this.properties.forEach(property => {
            typeCount[property.propertyType] = (typeCount[property.propertyType] || 0) + 1;
        });

        this.propertyTypeChart.data.labels = Object.keys(typeCount);
        this.propertyTypeChart.data.datasets[0].data = Object.values(typeCount);
        this.propertyTypeChart.update();
    }

    updateAgentPerformance(startDate, endDate) {
        const tbody = document.getElementById('agentPerformanceBody');
        tbody.innerHTML = '';

        this.agents.forEach(agent => {
            if (agent.role !== 'agent') return;

            const agentLeads = this.leads.filter(lead =>
                lead.assignedTo === agent.id &&
                new Date(lead.createdAt) >= startDate && new Date(lead.createdAt) <= endDate
            );

            const activeLeads = agentLeads.filter(lead => lead.status === 'In Progress').length;
            const convertedLeads = agentLeads.filter(lead => lead.status === 'Closed').length;
            const conversionRate = agentLeads.length ? (convertedLeads / agentLeads.length) * 100 : 0;

            const revenue = this.properties
                .filter(property => 
                    property.status === 'Sold' &&
                    property.assignedTo === agent.id &&
                    new Date(property.lastUpdated) >= startDate && new Date(property.lastUpdated) <= endDate
                )
                .reduce((sum, property) => sum + property.price, 0);

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${agent.name}</td>
                <td>${agentLeads.length}</td>
                <td>${activeLeads}</td>
                <td>${convertedLeads}</td>
                <td>${conversionRate.toFixed(1)}%</td>
                <td>₹${revenue.toLocaleString('en-IN')}</td>
                <td>
                    <div class="progress">
                        <div class="progress-bar bg-success" role="progressbar" 
                            style="width: ${conversionRate}%" 
                            aria-valuenow="${conversionRate}" 
                            aria-valuemin="0" 
                            aria-valuemax="100">
                        </div>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    updateLocationAnalysis(startDate, endDate) {
        const locationStats = {};
        const filteredLeads = this.leads.filter(lead =>
            new Date(lead.createdAt) >= startDate && new Date(lead.createdAt) <= endDate
        );

        filteredLeads.forEach(lead => {
            if (!locationStats[lead.location]) {
                locationStats[lead.location] = {
                    total: 0,
                    converted: 0
                };
            }
            locationStats[lead.location].total++;
            if (lead.status === 'Closed') {
                locationStats[lead.location].converted++;
            }
        });

        // Update chart
        const locations = Object.keys(locationStats);
        const totalLeads = locations.map(loc => locationStats[loc].total);
        const conversions = locations.map(loc => locationStats[loc].converted);

        this.locationAnalysisChart.data.labels = locations;
        this.locationAnalysisChart.data.datasets[0].data = totalLeads;
        this.locationAnalysisChart.data.datasets[1].data = conversions;
        this.locationAnalysisChart.update();

        // Update table
        const tbody = document.getElementById('locationAnalysisBody');
        tbody.innerHTML = '';
        locations.forEach(location => {
            const stats = locationStats[location];
            const conversionRate = stats.total ? (stats.converted / stats.total) * 100 : 0;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${location}</td>
                <td>${stats.total}</td>
                <td>${conversionRate.toFixed(1)}%</td>
            `;
            tbody.appendChild(row);
        });
    }

    generateCustomReport(formData) {
        const reportType = formData.get('reportType');
        const timeFrame = formData.get('timeFrame');
        const dateRange = formData.get('customDateRange');

        // Implement custom report generation based on selected parameters
        const reportContent = document.getElementById('customReportResult');
        reportContent.innerHTML = `<div class="alert alert-info">
            Generating ${reportType} report for ${timeFrame} timeframe...
        </div>`;
    }

    exportReport() {
        // Implement report export functionality
        // This could export to Excel, PDF, or CSV
        NotificationSystem.show('Report export feature coming soon!', 'info');
    }
}

// Initialize Report Manager
const reportManager = new ReportManager();

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notification.role = 'alert';
        notification.style.zIndex = '1050';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}
