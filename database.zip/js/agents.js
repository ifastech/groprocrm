// Agent Management System

class AgentManager {
    constructor() {
        this.agents = DataStorage.getData('agents') || [];
        this.leads = DataStorage.getData('leads') || [];
        this.properties = DataStorage.getData('properties') || [];
        this.setupEventListeners();
        this.updateAgentsView();
        this.updateStats();
    }

    setupEventListeners() {
        // Add Agent Form Handler
        const addAgentForm = document.getElementById('addAgentForm');
        if (addAgentForm) {
            addAgentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (!auth.hasPermission('agents', 'create')) {
                    NotificationSystem.show('You do not have permission to add agents', 'error');
                    return;
                }
                this.addAgent(this.getFormData(addAgentForm));
            });
        }

        // Listen for lead changes
        window.addEventListener('leadAdded', () => this.updateStats());
        window.addEventListener('leadUpdated', () => this.updateStats());
        window.addEventListener('leadDeleted', () => this.updateStats());

        // Listen for property changes
        window.addEventListener('propertyUpdated', () => this.updateStats());
    }

    getFormData(form) {
        const formData = new FormData(form);
        return {
            id: Date.now(),
            name: formData.get('fullName'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            password: formData.get('password'), // In production, hash the password
            commissionRate: parseFloat(formData.get('commissionRate')),
            status: formData.get('status'),
            role: 'agent',
            createdAt: new Date().toISOString(),
            createdBy: auth.currentUser.id
        };
    }

    addAgent(agentData) {
        // Check if email already exists
        if (this.agents.some(agent => agent.email === agentData.email)) {
            NotificationSystem.show('An agent with this email already exists', 'error');
            return;
        }

        this.agents.push(agentData);
        this.saveAgents();
        this.updateAgentsView();
        NotificationSystem.show('Agent added successfully', 'success');

        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('addAgentModal'));
        if (modal) modal.hide();

        // Reset form
        document.getElementById('addAgentForm').reset();

        // Trigger agent added event
        const agentAddedEvent = new CustomEvent('agentAdded', {
            detail: agentData
        });
        window.dispatchEvent(agentAddedEvent);
    }

    updateAgent(id, updatedData) {
        if (!auth.hasPermission('agents', 'update')) {
            NotificationSystem.show('You do not have permission to update agents', 'error');
            return;
        }
        const index = this.agents.findIndex(agent => agent.id === id);
        if (index !== -1) {
            this.agents[index] = { 
                ...this.agents[index], 
                ...updatedData,
                lastUpdated: new Date().toISOString()
            };
            this.saveAgents();
            this.updateAgentsView();
            NotificationSystem.show('Agent updated successfully', 'success');

            // Trigger agent updated event
            const agentUpdatedEvent = new CustomEvent('agentUpdated', {
                detail: this.agents[index]
            });
            window.dispatchEvent(agentUpdatedEvent);
        }
    }

    deleteAgent(id) {
        if (!auth.hasPermission('agents', 'delete')) {
            NotificationSystem.show('You do not have permission to delete agents', 'error');
            return;
        }
        
        const agent = this.agents.find(a => a.id === id);
        if (!agent) return;

        // Check if agent has active leads
        const activeLeads = this.leads.filter(lead => 
            lead.assignedTo === id && 
            lead.status !== 'Closed' && 
            lead.status !== 'Lost'
        );

        if (activeLeads.length > 0) {
            NotificationSystem.show('Cannot delete agent with active leads', 'error');
            return;
        }

        if (confirm('Are you sure you want to delete this agent?')) {
            this.agents = this.agents.filter(agent => agent.id !== id);
            this.saveAgents();
            this.updateAgentsView();
            NotificationSystem.show('Agent deleted successfully', 'success');

            // Trigger agent deleted event
            const agentDeletedEvent = new CustomEvent('agentDeleted', {
                detail: { id }
            });
            window.dispatchEvent(agentDeletedEvent);
        }
    }

    updateStats() {
        // Update total agents count
        document.getElementById('totalAgentsCount').textContent = 
            this.agents.filter(agent => agent.status === 'active').length;

        // Calculate average performance
        const agentPerformance = this.calculateAgentPerformance();
        const avgConversion = agentPerformance.reduce((sum, perf) => sum + perf.conversionRate, 0) / 
            (agentPerformance.length || 1);
        document.getElementById('avgPerformance').textContent = `${avgConversion.toFixed(1)}%`;

        // Update total leads
        const totalLeads = this.leads.filter(lead => lead.assignedTo).length;
        document.getElementById('totalAgentLeads').textContent = totalLeads;

        // Calculate total revenue
        const thisMonth = new Date().getMonth();
        const thisYear = new Date().getFullYear();
        const monthlyRevenue = this.properties
            .filter(property => {
                const soldDate = new Date(property.lastUpdated);
                return property.status === 'Sold' && 
                       soldDate.getMonth() === thisMonth &&
                       soldDate.getFullYear() === thisYear;
            })
            .reduce((sum, property) => sum + property.price, 0);
        document.getElementById('totalAgentRevenue').textContent = 
            `₹${monthlyRevenue.toLocaleString('en-IN')}`;
    }

    calculateAgentPerformance() {
        return this.agents.map(agent => {
            const agentLeads = this.leads.filter(lead => lead.assignedTo === agent.id);
            const convertedLeads = agentLeads.filter(lead => lead.status === 'Closed').length;
            const conversionRate = agentLeads.length ? (convertedLeads / agentLeads.length) * 100 : 0;
            
            const revenue = this.properties
                .filter(property => 
                    property.status === 'Sold' &&
                    property.assignedTo === agent.id
                )
                .reduce((sum, property) => sum + property.price, 0);

            return {
                ...agent,
                activeLeads: agentLeads.filter(lead => 
                    lead.status !== 'Closed' && lead.status !== 'Lost'
                ).length,
                conversionRate,
                revenue
            };
        });
    }

    updateAgentsView() {
        const tbody = document.getElementById('agentsTableBody');
        if (!tbody) return;

        const agentPerformance = this.calculateAgentPerformance();
        tbody.innerHTML = '';

        agentPerformance.forEach(agent => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${agent.name}</td>
                <td>${agent.email}</td>
                <td>${agent.phone}</td>
                <td>${agent.activeLeads}</td>
                <td>${agent.conversionRate.toFixed(1)}%</td>
                <td>₹${agent.revenue.toLocaleString('en-IN')}</td>
                <td>
                    <span class="badge bg-${agent.status === 'active' ? 'success' : 'secondary'}">
                        ${agent.status}
                    </span>
                </td>
                <td>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-info view-agent" data-id="${agent.id}">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${auth.hasPermission('agents', 'update') ? `
                            <button class="btn btn-sm btn-primary edit-agent" data-id="${agent.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                        ` : ''}
                        ${auth.hasPermission('agents', 'delete') ? `
                            <button class="btn btn-sm btn-danger delete-agent" data-id="${agent.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });

        this.setupRowEventListeners();
    }

    setupRowEventListeners() {
        // View Agent
        document.querySelectorAll('.view-agent').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                this.showAgentDetails(id);
            });
        });

        // Edit Agent
        document.querySelectorAll('.edit-agent').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                this.showEditModal(id);
            });
        });

        // Delete Agent
        document.querySelectorAll('.delete-agent').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                this.deleteAgent(id);
            });
        });
    }

    showAgentDetails(id) {
        const agent = this.agents.find(a => a.id === id);
        if (!agent) return;

        const agentLeads = this.leads.filter(lead => lead.assignedTo === id);
        const convertedLeads = agentLeads.filter(lead => lead.status === 'Closed');
        const revenue = this.properties
            .filter(property => 
                property.status === 'Sold' &&
                property.assignedTo === id
            )
            .reduce((sum, property) => sum + property.price, 0);

        const detailsContent = document.getElementById('agentDetailsContent');
        if (detailsContent) {
            detailsContent.innerHTML = `
                <div class="agent-details">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Basic Information</h6>
                            <p><strong>Name:</strong> ${agent.name}</p>
                            <p><strong>Email:</strong> ${agent.email}</p>
                            <p><strong>Phone:</strong> ${agent.phone}</p>
                            <p><strong>Status:</strong> ${agent.status}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Performance Metrics</h6>
                            <p><strong>Active Leads:</strong> ${agentLeads.length - convertedLeads.length}</p>
                            <p><strong>Converted Leads:</strong> ${convertedLeads.length}</p>
                            <p><strong>Conversion Rate:</strong> ${(convertedLeads.length / (agentLeads.length || 1) * 100).toFixed(1)}%</p>
                            <p><strong>Total Revenue:</strong> ₹${revenue.toLocaleString('en-IN')}</p>
                        </div>
                    </div>
                    <div class="mb-3">
                        <h6>Recent Activity</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Lead</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${agentLeads.slice(-5).map(lead => `
                                        <tr>
                                            <td>${new Date(lead.lastUpdated || lead.createdAt).toLocaleDateString()}</td>
                                            <td>${lead.name}</td>
                                            <td><span class="badge bg-${this.getStatusColor(lead.status)}">${lead.status}</span></td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        }

        const modal = new bootstrap.Modal(document.getElementById('viewAgentModal'));
        modal.show();
    }

    showEditModal(id) {
        const agent = this.agents.find(a => a.id === id);
        if (!agent) return;

        // Implement edit modal
        console.log('Show edit modal:', agent);
    }

    getStatusColor(status) {
        const colors = {
            'New': 'primary',
            'In Progress': 'warning',
            'Closed': 'success',
            'Lost': 'danger'
        };
        return colors[status] || 'secondary';
    }

    saveAgents() {
        DataStorage.saveData('agents', this.agents);
    }
}

// Initialize Agent Manager
const agentManager = new AgentManager();

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notification.role = 'alert';
        notification.style.zIndex = '1050';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}
