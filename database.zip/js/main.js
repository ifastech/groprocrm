// Main JavaScript for PropCRM

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    if (!window.auth || !window.auth.isAuthenticated) {
        window.location.href = 'login.html';
        return;
    }

    // Initialize navigation with active page
    Navigation.init('dashboard');

    // Initialize charts
    initializeCharts();

    // Update dashboard data
    updateDashboardData();

    // Setup event listeners
    setupEventListeners();

    // Update UI based on user role
    updateUIForRole();

    // Navigation Handling
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            
            // Check permission
            if (!auth.hasPermission(targetId, 'read')) {
                NotificationSystem.show('You do not have permission to access this section', 'error');
                return;
            }
            
            // Update active nav link
            navLinks.forEach(nl => nl.classList.remove('active'));
            link.classList.add('active');
            
            // Show target section, hide others
            sections.forEach(section => {
                if (section.id === targetId) {
                    section.classList.remove('d-none');
                    section.classList.add('fade-in');
                } else {
                    section.classList.add('d-none');
                    section.classList.remove('fade-in');
                }
            });
        });
    });

    // CRUD Operations for Leads
    class LeadManager {
        constructor() {
            this.leads = DataStorage.getData('leads') || [];
            this.agents = DataStorage.getData('agents') || [];
            this.setupEventListeners();
            this.updateLeadsTable();
        }

        setupEventListeners() {
            // Add Lead
            const addLeadForm = document.getElementById('addLeadForm');
            addLeadForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (!auth.hasPermission('leads', 'create')) {
                    NotificationSystem.show('You do not have permission to create leads', 'error');
                    return;
                }
                this.addLead(this.getFormData(addLeadForm));
            });

            // Search Leads
            const searchInput = document.querySelector('.search-box input');
            searchInput.addEventListener('input', (e) => {
                this.searchLeads(e.target.value);
            });

            // Lead Source Change Event
            const leadSourceSelect = document.querySelector('select[name="leadSource"]');
            if (leadSourceSelect) {
                leadSourceSelect.addEventListener('change', (e) => {
                    const sourceDetailsDiv = document.querySelector('.source-details');
                    if (e.target.value === 'Other') {
                        sourceDetailsDiv.classList.remove('d-none');
                    } else {
                        sourceDetailsDiv.classList.add('d-none');
                    }
                });
            }

            // Bulk Lead Assignment
            const bulkAssignBtn = document.getElementById('bulkAssignBtn');
            if (bulkAssignBtn) {
                bulkAssignBtn.addEventListener('click', () => this.showBulkAssignModal());
            }
        }

        getFormData(form) {
            const formData = new FormData(form);
            return {
                id: Date.now(),
                name: formData.get('fullName'),
                contact: formData.get('contact'),
                email: formData.get('email'),
                location: formData.get('location'),
                budget: formData.get('budget'),
                source: formData.get('leadSource'),
                sourceDetails: formData.get('sourceDetails'),
                status: 'New',
                assignedTo: null,
                assignedToName: null,
                createdAt: new Date().toISOString(),
                createdBy: auth.currentUser.id,
                notes: formData.get('notes')
            };
        }

        addLead(leadData) {
            this.leads.push(leadData);
            this.saveLeads();
            this.updateLeadsTable();
            NotificationSystem.show('Lead added successfully', 'success');

            // Trigger lead added event for client creation
            const leadAddedEvent = new CustomEvent('leadAdded', {
                detail: leadData
            });
            window.dispatchEvent(leadAddedEvent);

            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('addLeadModal'));
            modal.hide();
        }

        updateLead(id, updatedData) {
            if (!auth.hasPermission('leads', 'update')) {
                NotificationSystem.show('You do not have permission to update leads', 'error');
                return;
            }
            const index = this.leads.findIndex(lead => lead.id === id);
            if (index !== -1) {
                this.leads[index] = { ...this.leads[index], ...updatedData };
                this.saveLeads();
                this.updateLeadsTable();
                NotificationSystem.show('Lead updated successfully', 'success');
            }
        }

        deleteLead(id) {
            if (!auth.hasPermission('leads', 'delete')) {
                NotificationSystem.show('You do not have permission to delete leads', 'error');
                return;
            }
            this.leads = this.leads.filter(lead => lead.id !== id);
            this.saveLeads();
            this.updateLeadsTable();
            NotificationSystem.show('Lead deleted successfully', 'success');
        }

        searchLeads(searchTerm) {
            const filteredLeads = this.leads.filter(lead => 
                lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                lead.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                lead.contact.includes(searchTerm)
            );
            this.updateLeadsTable(filteredLeads);
        }

        showBulkAssignModal() {
            const selectedLeads = Array.from(document.querySelectorAll('input[name="leadSelect"]:checked'))
                .map(checkbox => parseInt(checkbox.value));
            
            if (selectedLeads.length === 0) {
                NotificationSystem.show('Please select leads to assign', 'warning');
                return;
            }

            const modal = new bootstrap.Modal(document.getElementById('assignLeadsModal'));
            const agentSelect = document.getElementById('assignAgent');
            
            // Populate agents dropdown
            agentSelect.innerHTML = '<option value="">Select Agent</option>';
            this.agents.forEach(agent => {
                if (agent.role === 'agent' && agent.status === 'active') {
                    agentSelect.innerHTML += `<option value="${agent.id}">${agent.name}</option>`;
                }
            });

            // Handle assignment
            document.getElementById('assignLeadsForm').onsubmit = (e) => {
                e.preventDefault();
                const agentId = agentSelect.value;
                const agent = this.agents.find(a => a.id === parseInt(agentId));
                
                if (!agentId) {
                    NotificationSystem.show('Please select an agent', 'warning');
                    return;
                }

                selectedLeads.forEach(leadId => {
                    const lead = this.leads.find(l => l.id === leadId);
                    if (lead) {
                        lead.assignedTo = parseInt(agentId);
                        lead.assignedToName = agent.name;
                        lead.assignedAt = new Date().toISOString();
                        lead.lastUpdated = new Date().toISOString();
                    }
                });

                this.saveLeads();
                this.updateLeadsTable();
                modal.hide();
                NotificationSystem.show(`${selectedLeads.length} leads assigned to ${agent.name}`, 'success');
            };

            modal.show();
        }

        updateLeadsTable(leadsToShow = this.leads) {
            const tbody = document.getElementById('leadsTableBody');
            tbody.innerHTML = '';
            
            leadsToShow.forEach(lead => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    ${auth.currentUser.role === 'admin' ? 
                        `<td><input type="checkbox" name="leadSelect" value="${lead.id}"></td>` : ''}
                    <td>${lead.name}</td>
                    <td>${lead.contact}</td>
                    <td>${lead.location}</td>
                    <td>${lead.budget}</td>
                    <td><span class="badge bg-${this.getStatusColor(lead.status)}">${lead.status}</span></td>
                    <td>${lead.source}${lead.sourceDetails ? ` (${lead.sourceDetails})` : ''}</td>
                    <td>${lead.assignedToName || '<span class="text-muted">Unassigned</span>'}</td>
                    <td>
                        ${auth.hasPermission('leads', 'update') ? 
                            `<button class="btn btn-sm btn-info edit-lead" data-id="${lead.id}">
                                <i class="fas fa-edit"></i>
                            </button>` : ''}
                        ${auth.hasPermission('leads', 'delete') ? 
                            `<button class="btn btn-sm btn-danger delete-lead" data-id="${lead.id}">
                                <i class="fas fa-trash"></i>
                            </button>` : ''}
                    </td>
                `;
                tbody.appendChild(row);
            });

            this.setupRowEventListeners();
        }

        setupRowEventListeners() {
            document.querySelectorAll('.edit-lead').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = parseInt(e.currentTarget.dataset.id);
                    this.showEditModal(id);
                });
            });

            document.querySelectorAll('.delete-lead').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = parseInt(e.currentTarget.dataset.id);
                    if (confirm('Are you sure you want to delete this lead?')) {
                        this.deleteLead(id);
                    }
                });
            });
        }

        getStatusColor(status) {
            const colors = {
                'New': 'primary',
                'In Progress': 'warning',
                'Closed': 'success',
                'Lost': 'danger'
            };
            return colors[status] || 'secondary';
        }

        showEditModal(id) {
            const lead = this.leads.find(l => l.id === id);
            if (!lead) return;

            // Implement edit modal logic here
            // Show modal with lead data and update on save
        }

        saveLeads() {
            DataStorage.saveData('leads', this.leads);
        }
    }

    // Initialize Lead Manager
    const leadManager = new LeadManager();

    // Update UI based on user role
    function updateUIForRole() {
        const user = auth.currentUser;
        
        // Update navbar based on permissions
        if (!auth.hasPermission('agents', 'read')) {
            const agentsLink = document.querySelector('a[href="agents.html"]');
            if (agentsLink) {
                agentsLink.parentElement.remove();
            }
        }
        
        // Update action buttons based on permissions
        if (!auth.hasPermission('leads', 'create')) {
            const addLeadBtn = document.querySelector('[data-bs-target="#addLeadModal"]');
            if (addLeadBtn) {
                addLeadBtn.remove();
            }
        }

        // Update user display name
        const userNameDisplay = document.getElementById('userNameDisplay');
        if (userNameDisplay) {
            userNameDisplay.textContent = user.name;
        }
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Main Application Controller

class AppController {
    constructor() {
        this.setupEventListeners();
        this.updateDashboardCounts();
        this.setupNavigation();
        this.initializeCharts();
    }

    setupEventListeners() {
        // Listen for lead changes
        window.addEventListener('leadAdded', this.handleLeadChange.bind(this));
        window.addEventListener('leadUpdated', this.handleLeadChange.bind(this));
        window.addEventListener('leadDeleted', this.handleLeadChange.bind(this));

        // Listen for property changes
        window.addEventListener('propertyAdded', this.handlePropertyChange.bind(this));
        window.addEventListener('propertyUpdated', this.handlePropertyChange.bind(this));
        window.addEventListener('propertyDeleted', this.handlePropertyChange.bind(this));

        // Listen for client changes
        window.addEventListener('clientAdded', this.handleClientChange.bind(this));
        window.addEventListener('clientUpdated', this.handleClientChange.bind(this));
        window.addEventListener('clientDeleted', this.handleClientChange.bind(this));

        // Dashboard timeframe change
        const timeframeSelect = document.getElementById('dashboardTimeframe');
        if (timeframeSelect) {
            timeframeSelect.addEventListener('change', () => {
                this.updateDashboardData();
            });
        }

        // Task form submission
        const addTaskForm = document.getElementById('addTaskForm');
        if (addTaskForm) {
            addTaskForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addTask(new FormData(addTaskForm));
            });
        }

        // Related item selection
        const relatedToSelect = document.querySelector('select[name="relatedTo"]');
        if (relatedToSelect) {
            relatedToSelect.addEventListener('change', (e) => {
                this.updateRelatedItems(e.target.value);
            });
        }
    }

    initializeCharts() {
        // Lead Pipeline Chart
        this.leadPipelineChart = new Chart(document.getElementById('leadPipelineChart'), {
            type: 'bar',
            data: {
                labels: ['New', 'Contacted', 'Site Visit', 'Negotiation', 'Closed', 'Lost'],
                datasets: [{
                    label: 'Leads',
                    data: [0, 0, 0, 0, 0, 0],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(40, 167, 69, 0.5)',
                        'rgba(220, 53, 69, 0.5)'
                    ],
                    borderColor: [
                        'rgb(54, 162, 235)',
                        'rgb(255, 206, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(153, 102, 255)',
                        'rgb(40, 167, 69)',
                        'rgb(220, 53, 69)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Revenue Trend Chart
        this.revenueTrendChart = new Chart(document.getElementById('revenueTrendChart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Revenue',
                    data: [],
                    borderColor: 'rgb(40, 167, 69)',
                    tension: 0.1,
                    fill: true,
                    backgroundColor: 'rgba(40, 167, 69, 0.1)'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString('en-IN');
                            }
                        }
                    }
                }
            }
        });

        // Property Types Chart
        this.propertyTypesChart = new Chart(document.getElementById('propertyTypesChart'), {
            type: 'doughnut',
            data: {
                labels: ['Apartment', 'Villa', 'Plot', 'Commercial'],
                datasets: [{
                    data: [0, 0, 0, 0],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(75, 192, 192, 0.8)',
                        'rgba(153, 102, 255, 0.8)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });

        // Lead Sources Chart
        this.leadSourcesChart = new Chart(document.getElementById('leadSourcesChart'), {
            type: 'pie',
            data: {
                labels: ['Website', 'Referral', 'Property Portal', 'Social Media', 'Direct', 'Other'],
                datasets: [{
                    data: [0, 0, 0, 0, 0, 0],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(75, 192, 192, 0.8)',
                        'rgba(153, 102, 255, 0.8)',
                        'rgba(255, 99, 132, 0.8)',
                        'rgba(201, 203, 207, 0.8)'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });

        // Location Chart
        this.locationChart = new Chart(document.getElementById('locationChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Properties',
                    data: [],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgb(54, 162, 235)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    updateDashboardData() {
        const timeframe = document.getElementById('dashboardTimeframe').value;
        const { startDate, endDate } = this.getDateRange(timeframe);
        
        this.updateStats(startDate, endDate);
        this.updateCharts(startDate, endDate);
        this.updateTables();
        this.updateTasksList();
        this.updateSiteVisitsList();
    }

    getDateRange(timeframe) {
        const now = new Date();
        let startDate = new Date();
        const endDate = now;

        switch (timeframe) {
            case 'today':
                startDate.setHours(0, 0, 0, 0);
                break;
            case 'week':
                startDate.setDate(now.getDate() - 7);
                break;
            case 'month':
                startDate.setMonth(now.getMonth() - 1);
                break;
            case 'year':
                startDate.setFullYear(now.getFullYear() - 1);
                break;
        }

        return { startDate, endDate };
    }

    setupNavigation() {
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && href.includes(currentPage)) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });

        // Update user info in navbar
        this.updateUserInfo();
    }

    updateUserInfo() {
        const navbar = document.querySelector('.navbar-nav');
        if (!navbar || !auth.currentUser) return;

        // Remove existing user nav if present
        const existingUserNav = document.querySelector('.user-nav');
        if (existingUserNav) {
            existingUserNav.remove();
        }

        const userNav = document.createElement('li');
        userNav.className = 'nav-item dropdown ms-auto user-nav';
        userNav.innerHTML = `
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                <i class="fas fa-user"></i> ${auth.currentUser.name}
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#" id="userProfile">Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="#" id="logoutBtn">Logout</a></li>
            </ul>
        `;
        navbar.appendChild(userNav);

        // Add logout functionality
        document.getElementById('logoutBtn').addEventListener('click', (e) => {
            e.preventDefault();
            auth.logout();
        });

        // Add profile functionality
        document.getElementById('userProfile').addEventListener('click', (e) => {
            e.preventDefault();
            this.showProfileModal();
        });
    }

    updateDashboardCounts() {
        if (!document.getElementById('dashboard')) return;

        const leads = DataStorage.getData('leads') || [];
        const properties = DataStorage.getData('properties') || [];
        const activeLeads = leads.filter(lead => lead.status !== 'Closed' && lead.status !== 'Lost').length;
        const siteVisits = leads.filter(lead => lead.status === 'Site Visit Scheduled').length;
        const closures = leads.filter(lead => lead.status === 'Closed').length;

        // Update dashboard counts
        document.getElementById('activeLeadsCount').textContent = activeLeads;
        document.getElementById('propertiesCount').textContent = properties.length;
        document.getElementById('siteVisitsCount').textContent = siteVisits;
        document.getElementById('closuresCount').textContent = closures;
    }

    handleLeadChange(event) {
        this.updateDashboardCounts();
        
        // Trigger client creation for new leads
        if (event.type === 'leadAdded') {
            const leadData = event.detail;
            this.createClientFromLead(leadData);
        }

        // Update reports if on reports page
        if (window.reportManager) {
            window.reportManager.updateReports();
        }
    }

    handlePropertyChange() {
        this.updateDashboardCounts();
        
        // Update reports if on reports page
        if (window.reportManager) {
            window.reportManager.updateReports();
        }
    }

    handleClientChange() {
        // Update reports if on reports page
        if (window.reportManager) {
            window.reportManager.updateReports();
        }
    }

    createClientFromLead(leadData) {
        const clients = DataStorage.getData('clients') || [];
        const existingClient = clients.find(client => 
            client.contact === leadData.contact || 
            (leadData.email && client.email === leadData.email)
        );

        if (!existingClient) {
            const clientData = {
                id: Date.now(),
                fullName: leadData.name,
                contact: leadData.contact,
                email: leadData.email,
                location: leadData.location,
                clientType: 'Buyer',
                status: 'Active',
                source: leadData.source,
                createdAt: new Date().toISOString(),
                lastInteraction: new Date().toISOString(),
                leads: [{
                    leadId: leadData.id,
                    date: new Date().toISOString(),
                    status: leadData.status
                }]
            };

            clients.push(clientData);
            DataStorage.saveData('clients', clients);

            // Trigger client added event
            const clientAddedEvent = new CustomEvent('clientAdded', {
                detail: clientData
            });
            window.dispatchEvent(clientAddedEvent);
        }
    }

    showProfileModal() {
        // Implement user profile modal
        NotificationSystem.show('Profile feature coming soon!', 'info');
    }
}

// Initialize App Controller
const app = new AppController();

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notification.role = 'alert';
        notification.style.zIndex = '1050';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }

    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}
