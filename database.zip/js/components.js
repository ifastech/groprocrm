// Common Components

class Navigation {
    static getNavHTML(activePage) {
        return `
            <div class="scroll-progress"></div>
            <nav class="navbar navbar-expand-lg navbar-dark bg-primary nav-down">
                <div class="container">
                    <a class="navbar-brand" href="index.html">
                        <i class="fas fa-building"></i> PropCRM
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link ${activePage === 'dashboard' ? 'active' : ''}" href="index.html">
                                    <i class="fas fa-chart-line"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link ${activePage === 'leads' ? 'active' : ''}" href="leads.html">
                                    <i class="fas fa-funnel-dollar"></i> Leads
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link ${activePage === 'properties' ? 'active' : ''}" href="properties.html">
                                    <i class="fas fa-home"></i> Properties
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link ${activePage === 'clients' ? 'active' : ''}" href="clients.html">
                                    <i class="fas fa-users"></i> Clients
                                </a>
                            </li>
                            <li class="nav-item admin-only">
                                <a class="nav-link ${activePage === 'agents' ? 'active' : ''}" href="agents.html">
                                    <i class="fas fa-user-tie"></i> Agents
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link ${activePage === 'reports' ? 'active' : ''}" href="reports.html">
                                    <i class="fas fa-chart-bar"></i> Reports
                                </a>
                            </li>
                        </ul>
                        <!-- User Profile Dropdown -->
                        <div class="nav-item dropdown">
                            <a class="user-profile-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <div class="user-avatar">
                                    <i class="fas fa-user"></i>
                                </div>
                                <span class="d-none d-md-inline" id="userNameDisplay">User</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="#" id="userProfileBtn">
                                        <i class="fas fa-user-circle me-2"></i> Profile
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#" id="userSettingsBtn">
                                        <i class="fas fa-cog me-2"></i> Settings
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="#" id="logoutBtn">
                                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
        `;
    }

    static init(activePage) {
        // Remove any existing navigation
        const existingNav = document.querySelector('nav.navbar');
        const existingProgress = document.querySelector('.scroll-progress');
        if (existingNav) existingNav.remove();
        if (existingProgress) existingProgress.remove();

        // Insert new navigation at the start of body
        const navElement = document.createElement('div');
        navElement.innerHTML = this.getNavHTML(activePage);
        document.body.insertAdjacentElement('afterbegin', navElement.firstElementChild); // Progress bar
        document.body.insertAdjacentElement('afterbegin', navElement.firstElementChild); // Navbar

        // Ensure main content has proper class
        const mainContent = document.querySelector('.container.mt-4');
        if (mainContent) {
            mainContent.classList.add('page-content');
        }

        // Setup event listeners
        this.setupEventListeners();
        this.setupPageTransitions();
        this.setupScrollHandling();
    }

    static setupEventListeners() {
        // Setup logout handler
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handlePageTransition(() => {
                    auth.logout();
                });
            });
        }

        // Update user name
        const userNameDisplay = document.getElementById('userNameDisplay');
        if (userNameDisplay && auth.currentUser) {
            userNameDisplay.textContent = auth.currentUser.name;
        }

        // Hide admin-only elements for non-admin users
        if (auth.currentUser && auth.currentUser.role !== 'admin') {
            document.querySelectorAll('.admin-only').forEach(el => {
                el.style.display = 'none';
            });
        }

        // Add hover effect to nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('mouseenter', () => {
                link.style.transform = 'translateY(-2px)';
            });
            link.addEventListener('mouseleave', () => {
                if (!link.classList.contains('active')) {
                    link.style.transform = '';
                }
            });
        });
    }

    static setupScrollHandling() {
        let lastScroll = 0;
        const navbar = document.querySelector('.navbar');
        const scrollProgress = document.querySelector('.scroll-progress');
        
        window.addEventListener('scroll', () => {
            // Update scroll progress
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            if (scrollProgress) {
                scrollProgress.style.transform = `scaleX(${scrolled / 100})`;
            }

            // Handle navbar visibility
            const currentScroll = window.pageYOffset;
            
            // Show navbar at the top
            if (currentScroll <= 0) {
                navbar.classList.remove('nav-up');
                navbar.classList.add('nav-down');
                return;
            }
            
            // Handle scroll direction
            if (currentScroll > lastScroll && currentScroll > 70) {
                // Scrolling down & past navbar height
                navbar.classList.remove('nav-down');
                navbar.classList.add('nav-up');
            } else if (currentScroll < lastScroll) {
                // Scrolling up
                navbar.classList.remove('nav-up');
                navbar.classList.add('nav-down');
            }
            
            lastScroll = currentScroll;
        });

        // Show navbar when hovering near top
        document.addEventListener('mousemove', (e) => {
            if (e.clientY <= 70) {
                navbar.classList.remove('nav-up');
                navbar.classList.add('nav-down');
            }
        });
    }

    static setupPageTransitions() {
        // Add page-content class to main content
        const mainContent = document.querySelector('.container.mt-4');
        if (mainContent) {
            mainContent.classList.add('page-content');
        }

        // Handle navigation clicks
        document.querySelectorAll('.nav-link').forEach(link => {
            if (!link.closest('.dropdown')) { // Exclude dropdown items
                link.addEventListener('click', (e) => {
                    const href = link.getAttribute('href');
                    if (href && href !== '#' && !link.classList.contains('active')) {
                        e.preventDefault();
                        this.handlePageTransition(() => {
                            window.location.href = href;
                        });
                    }
                });
            }
        });
    }

    static handlePageTransition(callback) {
        const mainContent = document.querySelector('.page-content');
        if (mainContent) {
            // Fade out
            mainContent.style.opacity = '0';
            mainContent.style.transform = 'translateY(20px)';
            setTimeout(() => {
                callback();
            }, 300);
        } else {
            callback();
        }
    }
}

// Export components
window.Navigation = Navigation;
