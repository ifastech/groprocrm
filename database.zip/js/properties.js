// Properties Management System

class PropertyManager {
    constructor() {
        this.properties = [];
        this.currentView = 'grid';
        this.loadProperties();
        this.initializeEventListeners();
    }

    loadProperties() {
        this.properties = DataStorage.getData('properties') || [];
        this.updatePropertiesView();
    }

    initializeEventListeners() {
        // View toggle buttons
        document.querySelectorAll('.view-toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.view-toggle-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentView = btn.dataset.view;
                this.updatePropertiesView();
            });
        });

        // Filter listeners
        const filterInputs = ['propertyTypeFilter', 'statusFilter', 'locationFilter', 'propertySearch'];
        filterInputs.forEach(id => {
            document.getElementById(id)?.addEventListener('input', this.debounce(() => this.updatePropertiesView(), 300));
        });

        // Add property form
        document.getElementById('addPropertyForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAddProperty(e.target);
        });
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    handleAddProperty(form) {
        if (!auth.hasPermission('properties', 'create')) {
            NotificationSystem.show('You do not have permission to add properties', 'error');
            return;
        }

        const formData = new FormData(form);
        const imageFiles = formData.getAll('images');
        const imageUrls = Array.from(imageFiles)
            .filter(file => file.size > 0)
            .map(file => URL.createObjectURL(file));

        const newProperty = {
            id: 'prop_' + Date.now(),
            title: formData.get('title'),
            propertyType: formData.get('propertyType'),
            price: parseFloat(formData.get('price')),
            area: parseFloat(formData.get('area')),
            location: formData.get('location'),
            bedrooms: parseInt(formData.get('bedrooms')) || 0,
            bathrooms: parseInt(formData.get('bathrooms')) || 0,
            status: formData.get('status'),
            furnishedStatus: formData.get('furnishedStatus'),
            features: formData.getAll('features'),
            description: formData.get('description'),
            images: imageUrls,
            createdAt: new Date().toISOString(),
            createdBy: auth.getCurrentUser()?.id,
            lastUpdated: new Date().toISOString()
        };

        this.properties.push(newProperty);
        this.saveProperties();
        this.updatePropertiesView();
        
        // Close modal and reset form
        bootstrap.Modal.getInstance(document.getElementById('addPropertyModal')).hide();
        form.reset();
        NotificationSystem.show('Property added successfully', 'success');
    }

    updatePropertiesView() {
        const filteredProperties = this.getFilteredProperties();
        
        if (this.currentView === 'grid') {
            this.renderGridView(filteredProperties);
        } else {
            this.renderListView(filteredProperties);
        }

        // Toggle view containers
        document.getElementById('propertiesGrid').classList.toggle('d-none', this.currentView !== 'grid');
        document.getElementById('propertiesList').classList.toggle('d-none', this.currentView !== 'list');
    }

    getFilteredProperties() {
        const typeFilter = document.getElementById('propertyTypeFilter').value.toLowerCase();
        const statusFilter = document.getElementById('statusFilter').value.toLowerCase();
        const locationFilter = document.getElementById('locationFilter').value.toLowerCase();
        const searchFilter = document.getElementById('propertySearch').value.toLowerCase();

        return this.properties.filter(property => {
            const matchesType = !typeFilter || property.propertyType.toLowerCase().includes(typeFilter);
            const matchesStatus = !statusFilter || property.status.toLowerCase().includes(statusFilter);
            const matchesLocation = !locationFilter || property.location.toLowerCase().includes(locationFilter);
            const matchesSearch = !searchFilter || 
                property.title.toLowerCase().includes(searchFilter) ||
                property.description.toLowerCase().includes(searchFilter);

            return matchesType && matchesStatus && matchesLocation && matchesSearch;
        });
    }

    renderGridView(properties) {
        const grid = document.getElementById('propertiesGrid');
        grid.innerHTML = properties.map(property => this.createPropertyCard(property)).join('');
    }

    renderListView(properties) {
        const tbody = document.getElementById('propertiesTableBody');
        tbody.innerHTML = properties.map(property => this.createPropertyRow(property)).join('');
    }

    createPropertyCard(property) {
        const canEdit = auth.hasPermission('properties', 'update');
        const canDelete = auth.hasPermission('properties', 'delete');
        
        return `
            <div class="col-md-6 col-lg-4">
                <div class="card property-card">
                    <div class="position-relative">
                        <img src="${property.images[0] || 'https://via.placeholder.com/400x300'}" class="property-image" alt="${property.title}">
                        <span class="property-status status-${property.status.toLowerCase()}">${property.status}</span>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title mb-1">${property.title}</h5>
                        <p class="property-location mb-2">
                            <i class="fas fa-map-marker-alt"></i>
                            ${property.location}
                        </p>
                        <div class="property-features">
                            ${property.bedrooms ? `<span><i class="fas fa-bed"></i> ${property.bedrooms} Beds</span>` : ''}
                            ${property.bathrooms ? `<span><i class="fas fa-bath"></i> ${property.bathrooms} Baths</span>` : ''}
                            <span><i class="fas fa-vector-square"></i> ${property.area} sqft</span>
                        </div>
                        <div class="property-amenities">
                            ${property.features.map(feature => 
                                `<span class="amenity-badge"><i class="fas fa-check"></i> ${feature}</span>`
                            ).join('')}
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="property-price">₹${property.price.toLocaleString()}</div>
                            <div class="btn-group">
                                ${canEdit ? `
                                    <button class="btn btn-outline-primary btn-sm" onclick="propertyManager.editProperty('${property.id}')">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                ` : ''}
                                ${canDelete ? `
                                    <button class="btn btn-outline-danger btn-sm" onclick="propertyManager.deleteProperty('${property.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    createPropertyRow(property) {
        const canEdit = auth.hasPermission('properties', 'update');
        const canDelete = auth.hasPermission('properties', 'delete');
        
        return `
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <img src="${property.images[0] || 'https://via.placeholder.com/50x50'}" 
                             class="rounded me-2" style="width: 50px; height: 50px; object-fit: cover;">
                        <div>
                            <div class="fw-bold">${property.title}</div>
                            <small class="text-muted">${property.propertyType}</small>
                        </div>
                    </div>
                </td>
                <td>${property.location}</td>
                <td>${property.propertyType}</td>
                <td>₹${property.price.toLocaleString()}</td>
                <td><span class="badge bg-${this.getStatusColor(property.status)}">${property.status}</span></td>
                <td>${new Date(property.createdAt).toLocaleDateString()}</td>
                <td>
                    <div class="btn-group">
                        ${canEdit ? `
                            <button class="btn btn-outline-primary btn-sm" onclick="propertyManager.editProperty('${property.id}')">
                                <i class="fas fa-edit"></i>
                            </button>
                        ` : ''}
                        ${canDelete ? `
                            <button class="btn btn-outline-danger btn-sm" onclick="propertyManager.deleteProperty('${property.id}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `;
    }

    getStatusColor(status) {
        const colors = {
            'Available': 'success',
            'Sold': 'danger',
            'Reserved': 'warning',
            'Under Maintenance': 'info'
        };
        return colors[status] || 'secondary';
    }

    editProperty(id) {
        const property = this.properties.find(p => p.id === id);
        if (!property) {
            NotificationSystem.show('Property not found', 'error');
            return;
        }

        if (!auth.hasPermission('properties', 'update')) {
            NotificationSystem.show('You do not have permission to edit properties', 'error');
            return;
        }

        // Populate edit form
        document.getElementById('editPropertyId').value = property.id;
        document.getElementById('editTitle').value = property.title;
        document.getElementById('editPropertyType').value = property.propertyType;
        document.getElementById('editPrice').value = property.price;
        document.getElementById('editArea').value = property.area;
        document.getElementById('editLocation').value = property.location;
        document.getElementById('editBedrooms').value = property.bedrooms || '';
        document.getElementById('editBathrooms').value = property.bathrooms || '';
        document.getElementById('editStatus').value = property.status;
        document.getElementById('editFurnishedStatus').value = property.furnishedStatus;
        document.getElementById('editDescription').value = property.description;

        // Clear and set features
        document.querySelectorAll('.edit-amenity').forEach(checkbox => {
            checkbox.checked = property.features?.includes(checkbox.value) || false;
        });

        // Display current images
        const currentImagesContainer = document.getElementById('editCurrentImages');
        currentImagesContainer.innerHTML = property.images.map((image, index) => `
            <div class="col-md-4 mb-3">
                <div class="position-relative">
                    <img src="${image}" class="img-thumbnail" alt="Property Image ${index + 1}">
                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 m-1 remove-image" 
                            data-image-index="${index}">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `).join('');

        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('editPropertyModal'));
        modal.show();
    }
filterDataForCurrentUser() {
    if (!this.currentUser) return;
    
    // If not admin, only show user's own leads and clients
    if (!auth.hasPermission('leads', 'viewAll')) {
        this.leads = this.leads.filter(lead => lead.assignedTo === this.currentUser.id);
        this.clients = this.clients.filter(client => client.assignedTo === this.currentUser.id);
    }
}
    deleteProperty(id) {
        if (!auth.hasPermission('properties', 'delete')) {
            NotificationSystem.show('You do not have permission to delete properties', 'error');
            return;
        }

        const property = this.properties.find(p => p.id === id);
        if (!property) {
            NotificationSystem.show('Property not found', 'error');
            return;
        }

        // Show delete confirmation modal
        const modal = new bootstrap.Modal(document.getElementById('deletePropertyModal'));
        const confirmBtn = document.getElementById('confirmDeleteBtn');
        
        // Remove old event listeners
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
        
        // Add new event listener
        newConfirmBtn.addEventListener('click', () => {
            this.properties = this.properties.filter(p => p.id !== id);
            this.saveProperties();
            this.updatePropertiesView();
            modal.hide();
            NotificationSystem.show('Property deleted successfully', 'success');
        });

        modal.show();
    }

    saveProperties() {
        DataStorage.saveData('properties', this.properties);
    }
}

// Initialize property manager
const propertyManager = new PropertyManager();

// Notification System
class NotificationSystem {
    static show(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        const container = document.createElement('div');
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        container.appendChild(toast);
        document.body.appendChild(container);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        toast.addEventListener('hidden.bs.toast', () => {
            container.remove();
        });
    }
}

// Data Storage
class DataStorage {
    static saveData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
        window.dispatchEvent(new Event(key + 'Updated'));
    }
    
    static getData(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    }
}
