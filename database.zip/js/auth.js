// Authentication and Role-based Access Control

// Sample user data (replace with backend API)
const users = [
    {
        id: 1,
        email: 'admin@propcrm.com',
        password: 'admin123', // In production, use hashed passwords
        role: 'admin',
        name: 'Admin User',
        status: 'active'
    },
    {
        id: 2,
        email: 'agent@propcrm.com',
        password: 'agent123',
        role: 'agent',
        name: 'Agent User',
        status: 'active'
    }
];

// Role permissions
const permissions = {
    admin: {
        dashboard: ['read', 'write'],
        leads: ['create', 'read', 'update', 'delete'],
        properties: ['create', 'read', 'update', 'delete'],
        clients: ['create', 'read', 'update', 'delete'],
        agents: ['create', 'read', 'update', 'delete'],
        reports: ['read', 'export']
    },
    agent: {
        dashboard: ['read'],
        leads: ['create', 'read', 'update'],
        properties: ['read'],
        clients: ['read', 'update'],
        reports: ['read']
    }
};

// Protected pages and their allowed roles
const protectedPages = {
    'index.html': ['admin'],
    'agent-dashboard.html': ['agent'],
    'leads.html': ['admin', 'agent'],
    'properties.html': ['admin', 'agent'],
    'clients.html': ['admin', 'agent'],
    'agents.html': ['admin'],
    'reports.html': ['admin', 'agent']
};

// Authentication class
class Auth {
    constructor() {
        this.isAuthenticated = false;
        this.currentUser = null;
        this.checkAuth();
        this.setupEventListeners();
        this.setupLogoutHandler();
    }

    setupEventListeners() {
        // Listen for storage events (for multi-tab synchronization)
        window.addEventListener('storage', (e) => {
            if (e.key === 'user') {
                if (!e.newValue) {
                    // User logged out in another tab
                    this.handleLogout();
                } else {
                    // User data updated in another tab
                    this.currentUser = JSON.parse(e.newValue);
                    this.isAuthenticated = true;
                    this.checkPageAccess();
                }
            }
        });
    }

    setupLogoutHandler() {
        // Add logout event listener to all pages
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }
    }

    checkAuth() {
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        const user = localStorage.getItem('user');
        
        if (user) {
            this.currentUser = JSON.parse(user);
            this.isAuthenticated = true;
            
            if (currentPage === 'login.html') {
                this.redirectToDashboard();
                return;
            }

            // Check if user has access to current page
            this.checkPageAccess();
        } else if (currentPage !== 'login.html') {
            this.handleLogout();
            return;
        }

        this.updateUI();
    }

    checkPageAccess() {
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        
        // Allow access to login page
        if (currentPage === 'login.html') return;

        // Check if page is protected
        if (protectedPages[currentPage]) {
            const allowedRoles = protectedPages[currentPage];
            if (!allowedRoles.includes(this.currentUser.role)) {
                // Redirect to appropriate dashboard
                this.redirectToDashboard();
            }
        }
    }

    login(email, password) {
        const user = users.find(u => u.email === email && u.password === password);
        if (user && user.status === 'active') {
            const { password, ...userWithoutPassword } = user;
            this.currentUser = userWithoutPassword;
            this.isAuthenticated = true;
            localStorage.setItem('user', JSON.stringify(userWithoutPassword));
            localStorage.setItem('lastActivity', new Date().toISOString());
            
            // Trigger auth state change event
            const authEvent = new CustomEvent('authStateChanged', {
                detail: { user: userWithoutPassword }
            });
            window.dispatchEvent(authEvent);
            
            // Redirect to appropriate dashboard
            this.redirectToDashboard();
            return true;
        }
        return false;
    }

    redirectToDashboard() {
        if (!this.currentUser) {
            this.handleLogout();
            return;
        }
        
        if (this.currentUser.role === 'admin') {
            window.location.href = 'index.html';
        } else if (this.currentUser.role === 'agent') {
            window.location.href = 'agent-dashboard.html';
        }
    }

    logout() {
        this.handleLogout();
    }

    handleLogout() {
        // Clear authentication state
        this.isAuthenticated = false;
        this.currentUser = null;
        
        // Clear storage
        localStorage.removeItem('user');
        localStorage.removeItem('lastActivity');
        
        // Clear any cached data
        localStorage.removeItem('leads');
        localStorage.removeItem('properties');
        localStorage.removeItem('clients');
        localStorage.removeItem('tasks');
        
        // Trigger auth state change event
        const authEvent = new CustomEvent('authStateChanged', {
            detail: { user: null }
        });
        window.dispatchEvent(authEvent);
        
        // Redirect to login
        this.redirectToLogin();
    }

    redirectToLogin() {
        // Ensure we're not already on the login page to prevent redirect loop
        if (window.location.pathname.split('/').pop() !== 'login.html') {
            window.location.href = 'login.html';
        }
    }

    hasPermission(module, action) {
        if (!this.isAuthenticated || !this.currentUser) return false;
        const rolePermissions = permissions[this.currentUser.role];
        return rolePermissions && 
               rolePermissions[module] && 
               rolePermissions[module].includes(action);
    }

    updateUI() {
        // Update UI based on authentication state
        document.body.classList.toggle('authenticated', this.isAuthenticated);
        
        // Show/hide admin-only elements
        const adminElements = document.querySelectorAll('.admin-only');
        adminElements.forEach(element => {
            element.style.display = 
                this.currentUser && this.currentUser.role === 'admin' ? '' : 'none';
        });

        // Show/hide agent-only elements
        const agentElements = document.querySelectorAll('.agent-only');
        agentElements.forEach(element => {
            element.style.display = 
                this.currentUser && this.currentUser.role === 'agent' ? '' : 'none';
        });

        // Update user name display
        const userNameDisplay = document.getElementById('userNameDisplay');
        if (userNameDisplay && this.currentUser) {
            userNameDisplay.textContent = this.currentUser.name;
        }
    }

    checkSession() {
        const lastActivity = localStorage.getItem('lastActivity');
        if (lastActivity) {
            const inactiveTime = new Date() - new Date(lastActivity);
            const sessionTimeout = 30 * 60 * 1000; // 30 minutes
            
            if (inactiveTime > sessionTimeout) {
                this.handleLogout();
                return false;
            }
            
            // Update last activity
            localStorage.setItem('lastActivity', new Date().toISOString());
        }
        return true;
    }
}

// Initialize authentication
const auth = new Auth();

// Handle login form submission
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        if (auth.login(email, password)) {
            // Redirect is handled in login method
        } else {
            NotificationSystem.show('Invalid credentials or inactive account', 'error');
        }
    });
}

// Session activity monitoring
document.addEventListener('click', () => {
    if (auth.isAuthenticated) {
        auth.checkSession();
    }
});

// Export auth instance
window.auth = auth;
